from flask import Flask, request, render_template_string

app = Flask(__name__)

@app.route('/')
def index():
    return '''
    <h2>Hi, Guess My Name !!!</h2>
    <p>Enter my name:</p>
    <form action="/vuln" method="GET">
        <input type="text" name="name">
        <input type="submit" value="Submit">
    </form>
    '''

@app.route('/vuln')
def vuln():
    user_input = request.args.get('name', '')
    template = f"Not My name, {user_input} ðŸ˜œ !"
    return render_template_string(template)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)



